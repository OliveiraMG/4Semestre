package sptech.koinpoc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import org.koin.compose.koinInject

import sptech.koinpoc.comonentes.SessaoUsuario
import sptech.koinpoc.ui.theme.KoinPOCTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KoinPOCTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Tela("Android")
                }
            }
        }
    }
}

@Composable
fun Tela(name: String, modifier: Modifier = Modifier, sessaoUsuario: SessaoUsuario = koinInject()) {
    if (sessaoUsuario.inicializada()) {
        val usuario = sessaoUsuario.getDadosUsuario()
        Text(
            text = "Olá ${usuario.nome} Seu token é ${usuario.token}!",
            modifier = modifier,
            style = TextStyle(fontSize = 35.sp, color = Color.Blue)
        )
    } else {
        Text(
            text = "Eu te conheço?!",
            modifier = modifier,
            style = TextStyle(fontSize = 55.sp, color = Color.Red)
        )
    }

}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    KoinPOCTheme {
        Tela("Android")
    }
}