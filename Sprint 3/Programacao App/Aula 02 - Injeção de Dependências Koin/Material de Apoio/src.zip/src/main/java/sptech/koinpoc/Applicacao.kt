package sptech.koinpoc

import android.app.Application
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.GlobalContext.startKoin
import sptech.koinpoc.di.moduloMock
import sptech.koinpoc.di.moduloReal

class Applicacao: Application() {

    override fun onCreate() {
        super.onCreate()

        startKoin{
            androidContext(this@Applicacao)
            modules(moduloMock)
        }
    }
}