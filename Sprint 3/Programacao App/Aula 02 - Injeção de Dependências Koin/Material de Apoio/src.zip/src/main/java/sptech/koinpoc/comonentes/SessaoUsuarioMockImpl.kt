package sptech.koinpoc.comonentes

import sptech.koinpoc.dominio.DadosUsuario

class SessaoUsuarioMockImpl: SessaoUsuario {

    private val dadosUsuario: DadosUsuario = DadosUsuario(
        "fulano",
        "Zé Ruela",
        "123abc"
    )

    override fun setDadosUsuario(dadosUsuario: DadosUsuario) {
    }

    override fun getDadosUsuario(): DadosUsuario {
        return dadosUsuario
    }

    override fun inicializada() = true

}