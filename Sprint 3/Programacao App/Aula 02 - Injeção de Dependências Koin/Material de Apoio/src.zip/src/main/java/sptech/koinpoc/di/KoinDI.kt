package sptech.koinpoc.di

import org.koin.dsl.module
import sptech.koinpoc.comonentes.SessaoUsuario
import sptech.koinpoc.comonentes.SessaoUsuarioImpl
import sptech.koinpoc.comonentes.SessaoUsuarioMockImpl

val moduloMock = module {

    single<SessaoUsuario> {
        SessaoUsuarioMockImpl()
    }

}

val moduloReal = module {

    single<SessaoUsuario> {
        SessaoUsuarioImpl()
    }

}