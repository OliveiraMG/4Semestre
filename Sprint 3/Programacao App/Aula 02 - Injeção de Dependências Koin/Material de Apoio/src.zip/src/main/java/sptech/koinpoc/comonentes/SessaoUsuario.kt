package sptech.koinpoc.comonentes

import sptech.koinpoc.dominio.DadosUsuario

interface SessaoUsuario {

    fun setDadosUsuario(dadosUsuario: DadosUsuario)

    fun getDadosUsuario(): DadosUsuario

    fun inicializada(): Boolean

}