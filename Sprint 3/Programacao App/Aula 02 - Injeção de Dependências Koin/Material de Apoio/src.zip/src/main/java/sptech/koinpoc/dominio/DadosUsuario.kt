package sptech.koinpoc.dominio

data class DadosUsuario(
    val login: String,
    val nome: String,
    val token: String
)
