package sptech.koinpoc.comonentes

import sptech.koinpoc.dominio.DadosUsuario

class SessaoUsuarioImpl: SessaoUsuario {

    private lateinit var dadosUsuario: DadosUsuario

    override fun setDadosUsuario(dadosUsuario: DadosUsuario) {
        this.dadosUsuario = dadosUsuario
    }

    override fun getDadosUsuario(): DadosUsuario {
        return dadosUsuario
    }

    override fun inicializada(): Boolean {
        return this::dadosUsuario.isInitialized
    }

}